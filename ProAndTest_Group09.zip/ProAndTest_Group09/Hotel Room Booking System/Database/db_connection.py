import sqlite3
import os

# Lấy đường dẫn folder hiện tại
DB_PATH = os.path.join(os.path.dirname(__file__), "hotel.db")

def get_connection():
    return sqlite3.connect(DB_PATH)