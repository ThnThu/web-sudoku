from db_connection import get_connection

def seed_all():
    conn = get_connection()
    cur = conn.cursor()

    # Check if admin already exists
    cur.execute("SELECT COUNT(*) FROM users WHERE email = 'admin@gmail.com'")
    if cur.fetchone()[0] == 0:
        cur.execute("""
        INSERT INTO users (full_name, email, password, role, phone)
        VALUES (?, ?, ?, ?, ?)
        """, ('Admin', 'admin@gmail.com', '123', 'admin', '000'))

    # Check if rooms already exist
    cur.execute("SELECT COUNT(*) FROM rooms")
    if cur.fetchone()[0] == 0:
        rooms = [
            ("Room 101", "Single", 500000, "available"),
            ("Room 102", "Double", 700000, "available"),
            ("Room 201", "Suite", 1200000, "available")
        ]

        cur.executemany("""
        INSERT INTO rooms (room_name, room_type, price, status)
        VALUES (?, ?, ?, ?)
        """, rooms)

    conn.commit()
    conn.close()
    print("✓ Seed dữ liệu thành công!")

if __name__ == "__main__":
    seed_all()