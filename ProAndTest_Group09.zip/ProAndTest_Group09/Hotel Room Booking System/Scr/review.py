# review.py
from db_connection import get_connection
from datetime import datetime

def add_review(booking_id, user_id, room_id, rating, comment):
    """Thêm đánh giá cho booking"""
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        # Kiểm tra xem booking có tồn tại và đã hoàn thành chưa
        cur.execute("""
        SELECT status FROM bookings 
        WHERE booking_id = ? AND user_id = ?
        """, (booking_id, user_id))
        
        booking = cur.fetchone()
        if not booking:
            print(f"✗ Booking không tồn tại hoặc không thuộc về user")
            return False
        
        # MỞ RỘNG: Cho phép đánh giá cả booking 'paid' và 'cancelled' (để demo)
        if booking[0] not in ['paid', 'cancelled']:
            print(f"✗ Chỉ có thể đánh giá booking đã thanh toán hoặc đã hủy")
            return False
        
        # Kiểm tra xem đã review chưa
        cur.execute("SELECT review_id FROM reviews WHERE booking_id = ?", (booking_id,))
        if cur.fetchone():
            print(f"✗ Booking này đã được đánh giá")
            return False
        
        # Thêm review
        cur.execute("""
        INSERT INTO reviews (booking_id, user_id, room_id, rating, comment, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (booking_id, user_id, room_id, rating, comment, 
              datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        
        conn.commit()
        print(f"✓ Đã thêm review cho booking {booking_id}")
        return True
    except Exception as e:
        print(f"✗ Lỗi khi thêm review: {e}")
        return False
    finally:
        conn.close()

def get_reviews_by_room(room_id):
    """Lấy tất cả review của một phòng"""
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute("""
    SELECT r.review_id, r.rating, r.comment, r.created_at, u.full_name
    FROM reviews r
    JOIN users u ON r.user_id = u.user_id
    WHERE r.room_id = ?
    ORDER BY r.created_at DESC
    """, (room_id,))
    
    reviews = cur.fetchall()
    conn.close()
    return reviews

def get_reviews_by_user(user_id):
    """Lấy tất cả review của một user"""
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute("""
    SELECT r.review_id, r.rating, r.comment, r.created_at, rm.room_name
    FROM reviews r
    JOIN rooms rm ON r.room_id = rm.room_id
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
    """, (user_id,))
    
    reviews = cur.fetchall()
    conn.close()
    return reviews

def get_all_reviews():
    """Lấy tất cả review (cho admin)"""
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute("""
    SELECT r.review_id, u.full_name, rm.room_name, r.rating, r.comment, r.created_at
    FROM reviews r
    JOIN users u ON r.user_id = u.user_id
    JOIN rooms rm ON r.room_id = rm.room_id
    ORDER BY r.created_at DESC
    """)
    
    reviews = cur.fetchall()
    conn.close()
    return reviews

def get_average_rating(room_id):
    """Tính điểm trung bình của một phòng"""
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute("""
    SELECT AVG(rating), COUNT(*) 
    FROM reviews 
    WHERE room_id = ?
    """, (room_id,))
    
    result = cur.fetchone()
    conn.close()
    
    if result and result[0]:
        return round(result[0], 1), result[1]
    return 0, 0

def can_review_booking(booking_id, user_id):
    """Kiểm tra xem booking có thể review không"""
    conn = get_connection()
    cur = conn.cursor()
    
    # Kiểm tra booking có tồn tại, đã thanh toán hoặc đã hủy và chưa review
    cur.execute("""
    SELECT b.status, 
           (SELECT COUNT(*) FROM reviews WHERE booking_id = ?) as has_review
    FROM bookings b
    WHERE b.booking_id = ? AND b.user_id = ?
    """, (booking_id, booking_id, user_id))
    
    result = cur.fetchone()
    conn.close()
    
    if not result:
        return False, "Booking không tồn tại"
    
    # MỞ RỘNG: Cho phép đánh giá cả booking 'paid' và 'cancelled'
    if result[0] not in ['paid', 'cancelled']:
        return False, "Chỉ có thể đánh giá booking đã thanh toán hoặc đã hủy"
    
    if result[1] > 0:
        return False, "Booking này đã được đánh giá"
    
    return True, "Có thể đánh giá"