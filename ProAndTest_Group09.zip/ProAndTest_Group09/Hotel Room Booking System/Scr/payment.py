from db_connection import get_connection
from datetime import datetime

def create_payment(booking_id, amount, method):
    conn = get_connection()
    cur = conn.cursor()

    try:
        # Kiểm tra booking tồn tại
        cur.execute("""
        SELECT booking_id FROM bookings WHERE booking_id = ?
        """, (booking_id,))
        
        if not cur.fetchone():
            print("✗ Booking not found!")
            return False

        # Tạo payment
        cur.execute("""
        INSERT INTO payments (booking_id, amount, method, status, created_at)
        VALUES (?, ?, ?, ?, ?)
        """, (booking_id, amount, method, "PAID", 
              datetime.now().strftime("%Y-%m-%d %H:%M:%S")))

        conn.commit()
        print(f"✓ Payment created for booking {booking_id}")
        return True
    except Exception as e:
        print(f"✗ Payment creation failed: {e}")
        return False
    finally:
        conn.close()

# THÊM: Hàm lấy payment history
def get_payment_history(booking_id):
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute("""
    SELECT payment_id, amount, method, created_at 
    FROM payments 
    WHERE booking_id = ?
    ORDER BY created_at DESC
    """, (booking_id,))
    
    payments = cur.fetchall()
    conn.close()
    return payments