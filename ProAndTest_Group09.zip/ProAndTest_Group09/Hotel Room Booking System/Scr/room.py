from db_connection import get_connection

def get_available_rooms():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM rooms WHERE status='available'")
    rooms = cur.fetchall()
    conn.close()
    return rooms

def get_all_rooms():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM rooms")
    rooms = cur.fetchall()
    conn.close()
    return rooms

def get_room_by_id(room_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM rooms WHERE room_id = ?", (room_id,))
    room = cur.fetchone()
    conn.close()
    return room

def display_rooms(rooms):
    if not rooms:
        print("No rooms found!")
        return
    
    print("\n" + "="*70)
    print(f"{'ID':<5} {'Room Name':<15} {'Type':<12} {'Price':<12} {'Status':<10}")
    print("="*70)
    for room in rooms:
        room_id, room_name, room_type, price, status = room
        print(f"{room_id:<5} {room_name:<15} {room_type:<12} {price:>10,.0f} VND {status:<10}")
    print("="*70 + "\n")

# Thêm vào room.py
def get_rooms_with_ratings():
    """Lấy danh sách phòng kèm điểm đánh giá trung bình"""
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute("""
    SELECT r.room_id, r.room_name, r.room_type, r.price, r.status,
           COALESCE(AVG(rv.rating), 0) as avg_rating,
           COUNT(rv.review_id) as review_count
    FROM rooms r
    LEFT JOIN reviews rv ON r.room_id = rv.room_id
    GROUP BY r.room_id
    ORDER BY r.room_id
    """)
    
    rooms = cur.fetchall()
    conn.close()
    return rooms