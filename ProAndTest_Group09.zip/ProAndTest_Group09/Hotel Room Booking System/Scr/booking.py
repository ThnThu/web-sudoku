from db_connection import get_connection
from datetime import datetime


def create_booking(user_id, room_id, check_in_date, check_out_date):
    conn = get_connection()
    cur = conn.cursor()

    try:
        cur.execute("""
        INSERT INTO bookings (user_id, room_id, check_in_date, check_out_date, status)
        VALUES (?, ?, ?, ?, 'pending')
        """, (user_id, room_id, check_in_date, check_out_date))

        cur.execute("""
        UPDATE rooms SET status='booked' WHERE room_id=?
        """, (room_id,))

        conn.commit()
        print("✓ Booking created successfully!")
        return True
    except Exception as e:
        print(f"✗ Booking failed: {e}")
        return False
    finally:
        conn.close()


def get_user_bookings(user_id):
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
    SELECT b.booking_id, b.room_id, r.room_name,
           b.check_in_date, b.check_out_date, b.status
    FROM bookings b
    JOIN rooms r ON b.room_id = r.room_id
    WHERE b.user_id = ?
    """, (user_id,))

    bookings = cur.fetchall()
    conn.close()
    return bookings


def cancel_booking(booking_id):
    conn = get_connection()
    cur = conn.cursor()

    try:
        cur.execute(
            "SELECT room_id FROM bookings WHERE booking_id = ?",
            (booking_id,)
        )
        result = cur.fetchone()

        if result:
            room_id = result[0]

            cur.execute("""
                UPDATE bookings
                SET status='cancelled'
                WHERE booking_id = ?
            """, (booking_id,))

            cur.execute("""
                UPDATE rooms
                SET status='available'
                WHERE room_id = ?
            """, (room_id,))

            conn.commit()
            print("✓ Booking cancelled!")
            return True
        else:
            print("✗ Booking not found!")
            return False
    except Exception as e:
        print(f"✗ Cancel failed: {e}")
        return False
    finally:
        conn.close()


# ===================== PAYMENT (NEW) =====================

def get_booking_amount(booking_id):
    """
    Calculate total amount = number of days * room price
    """
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT b.check_in_date, b.check_out_date, r.price
        FROM bookings b
        JOIN rooms r ON b.room_id = r.room_id
        WHERE b.booking_id = ?
    """, (booking_id,))

    row = cur.fetchone()
    conn.close()

    if not row:
        return 0

    check_in, check_out, price = row
    
    # FIX: Tính số ngày chính xác
    try:
        checkin_date = datetime.strptime(check_in, "%Y-%m-%d")
        checkout_date = datetime.strptime(check_out, "%Y-%m-%d")
        days = (checkout_date - checkin_date).days
        
        # Đảm bảo số ngày ít nhất là 1
        if days <= 0:
            days = 1
            
        # DEBUG để kiểm tra
        print(f"DEBUG - Booking {booking_id}:")
        print(f"  Check-in: {check_in}, Check-out: {check_out}")
        print(f"  Days: {days}, Price: {price}")
        print(f"  Total: {days * price}")
        
        return days * price
    except Exception as e:
        print(f"Error calculating days: {e}")
        return price  # Trả về giá 1 ngày nếu có lỗi


def mark_as_paid(booking_id):
    conn = get_connection()
    cur = conn.cursor()

    try:
        cur.execute("""
            UPDATE bookings
            SET status='paid'
            WHERE booking_id = ?
        """, (booking_id,))

        cur.execute("""
            UPDATE rooms
            SET status='occupied'
            WHERE room_id = (
                SELECT room_id FROM bookings WHERE booking_id = ?
            )
        """, (booking_id,))

        conn.commit()
        return True
    except Exception as e:
        print(f"✗ Payment update failed: {e}")
        return False
    finally:
        conn.close()


def get_booking_status(booking_id):
    """
    Always check real status from database
    """
    conn = get_connection()
    cur = conn.cursor()

    cur.execute(
        "SELECT status FROM bookings WHERE booking_id = ?",
        (booking_id,)
    )
    row = cur.fetchone()
    conn.close()

    return row[0] if row else None