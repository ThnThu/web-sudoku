from db_connection import get_connection

def register(full_name, email, password, phone):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("""
        INSERT INTO users (full_name, email, password, role, phone)
        VALUES (?, ?, ?, 'customer', ?)
        """, (full_name, email, password, phone))
        conn.commit()
        print("✓ Register success!")
        return True
    except Exception as e:
        print(f"✗ Register failed: {e}")
        return False
    finally:
        conn.close()

def login(email, password):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
    SELECT user_id, full_name, role FROM users
    WHERE email=? AND password=?
    """, (email, password))
    user = cur.fetchone()
    conn.close()

    if user:
        return {
            "user_id": user[0],
            "full_name": user[1],
            "role": user[2]
        }
    return None