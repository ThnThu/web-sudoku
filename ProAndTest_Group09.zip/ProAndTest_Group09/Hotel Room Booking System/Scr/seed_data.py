from db_connection import get_connection
from datetime import datetime

def seed_all():
    conn = get_connection()
    cur = conn.cursor()

    # ========== ADMIN ==========
    cur.execute("SELECT COUNT(*) FROM users WHERE email = 'admin@gmail.com'")
    if cur.fetchone()[0] == 0:
        cur.execute("""
        INSERT INTO users (full_name, email, password, role, phone)
        VALUES (?, ?, ?, ?, ?)
        """, ('Admin', 'admin@gmail.com', '123', 'admin', '000'))

    # ========== CUSTOMER ==========
    cur.execute("SELECT COUNT(*) FROM users WHERE email = 'customer@gmail.com'")
    if cur.fetchone()[0] == 0:
        cur.execute("""
        INSERT INTO users (full_name, email, password, role, phone)
        VALUES (?, ?, ?, ?, ?)
        """, ('Customer', 'customer@gmail.com', '123', 'customer', '111'))

    # ========== ROOMS ==========
    cur.execute("SELECT COUNT(*) FROM rooms")
    if cur.fetchone()[0] == 0:
        rooms = [
            ("Room 101", "Single", 500000, "available"),
            ("Room 102", "Double", 700000, "available"),
            ("Room 201", "Suite", 1200000, "available")
        ]
        cur.executemany("""
        INSERT INTO rooms (room_name, room_type, price, status)
        VALUES (?, ?, ?, ?)
        """, rooms)

    # ========== REVIEWS ==========
    cur.execute("SELECT COUNT(*) FROM reviews")
    if cur.fetchone()[0] == 0:
        # Lấy user_id
        cur.execute("SELECT user_id FROM users WHERE email = 'customer@gmail.com'")
        user_id = cur.fetchone()[0]

        # Lấy room_id
        cur.execute("SELECT room_id FROM rooms WHERE room_name = 'Room 101'")
        room_id = cur.fetchone()[0]

        # Tạo booking đã paid
        cur.execute("""
        INSERT INTO bookings (user_id, room_id, check_in_date, check_out_date, status)
        VALUES (?, ?, ?, ?, 'paid')
        """, (user_id, room_id, '2024-01-15', '2024-01-17'))

        booking_id = cur.lastrowid

        # Insert review
        cur.execute("""
        INSERT INTO reviews (booking_id, user_id, room_id, rating, comment, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (
            booking_id,
            user_id,
            room_id,
            5,
            "Phòng rất đẹp, sạch sẽ, nhân viên thân thiện!",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ))

    conn.commit()
    conn.close()
    print("✓ Seed dữ liệu thành công!")

if __name__ == "__main__":
    seed_all()
