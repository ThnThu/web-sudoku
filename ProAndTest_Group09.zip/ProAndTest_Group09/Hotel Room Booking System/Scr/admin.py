from db_connection import get_connection

def get_all_rooms():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM rooms")
    rooms = cur.fetchall()
    conn.close()
    return rooms

def update_room_status(room_id, status):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
    UPDATE rooms SET status=? WHERE room_id=?
    """, (status, room_id))
    conn.commit()
    conn.close()
    print(f" Room {room_id} status updated to '{status}'")
def get_all_bookings():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
    SELECT b.booking_id, u.full_name, r.room_name, b.status
    FROM bookings b
    JOIN users u ON b.user_id = u.user_id
    JOIN rooms r ON b.room_id = r.room_id
    """)
    data = cur.fetchall()
    conn.close()
    return data
    