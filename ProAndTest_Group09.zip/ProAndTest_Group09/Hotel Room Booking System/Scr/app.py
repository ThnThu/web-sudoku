import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import os
import sqlite3

# ==================== DATABASE CONNECTION ====================
def get_connection():
    """Tạo kết nối database"""
    conn = sqlite3.connect('hotel_management.db')
    conn.row_factory = sqlite3.Row
    return conn

# ==================== CREATE TABLES ====================
def create_tables():
    """Tạo các bảng trong database"""
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            phone TEXT,
            role TEXT DEFAULT 'customer'
        )
    ''')
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS rooms (
            room_id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_number TEXT UNIQUE NOT NULL,
            room_type TEXT NOT NULL,
            price REAL NOT NULL,
            status TEXT DEFAULT 'available',
            description TEXT
        )
    ''')
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            room_id INTEGER,
            check_in_date TEXT NOT NULL,
            check_out_date TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            total_price REAL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id),
            FOREIGN KEY (room_id) REFERENCES rooms(room_id)
        )
    ''')
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS payments (
            payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER,
            amount REAL NOT NULL,
            payment_method TEXT,
            payment_date TEXT DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'pending',
            FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
        )
    ''')
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS reviews (
            review_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            booking_id INTEGER,
            rating INTEGER CHECK(rating >= 1 AND rating <= 5),
            comment TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id),
            FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
        )
    ''')
    
    conn.commit()
    conn.close()

# ==================== SEED DATA ====================
def seed_all():
    """Tạo dữ liệu mẫu"""
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        users = [
            ('Admin User', 'admin@gmail.com', '123', '0901234567', 'admin'),
            ('John Customer', 'customer@gmail.com', '123', '0912345678', 'customer'),
            ('VIP Customer', 'vip@gmail.com', '123', '0923456789', 'customer')
        ]
        cur.executemany('INSERT INTO users (full_name, email, password, phone, role) VALUES (?, ?, ?, ?, ?)', users)
        
        rooms = [
            ('101', 'Standard', 500000, 'available', 'Phòng tiêu chuẩn với đầy đủ tiện nghi'),
            ('102', 'Standard', 500000, 'available', 'Phòng tiêu chuẩn với đầy đủ tiện nghi'),
            ('201', 'Deluxe', 800000, 'available', 'Phòng cao cấp với view đẹp'),
            ('202', 'Deluxe', 800000, 'available', 'Phòng cao cấp với view đẹp'),
            ('301', 'Suite', 1200000, 'available', 'Phòng suite sang trọng'),
            ('302', 'Suite', 1200000, 'available', 'Phòng suite sang trọng'),
            ('401', 'VIP', 2000000, 'available', 'Phòng VIP cao cấp nhất'),
            ('402', 'VIP', 2000000, 'available', 'Phòng VIP cao cấp nhất')
        ]
        cur.executemany('INSERT INTO rooms (room_number, room_type, price, status, description) VALUES (?, ?, ?, ?, ?)', rooms)
        
    conn.commit()
    conn.close()

# ==================== AUTH MODULE ====================
class Auth:
    @staticmethod
    def login(email, password):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email = ? AND password = ?", (email, password))
        user = cur.fetchone()
        conn.close()
        if user:
            return dict(user)
        return None
    
    @staticmethod
    def register(name, email, password, phone):
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("INSERT INTO users (full_name, email, password, phone) VALUES (?, ?, ?, ?)",
                       (name, email, password, phone))
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            return False

auth = Auth()

# ==================== ROOM MODULE ====================
class Room:
    @staticmethod
    def get_available_rooms():
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT room_id, room_number, room_type, price, status FROM rooms WHERE status = 'available'")
        rooms = cur.fetchall()
        conn.close()
        return [tuple(r) for r in rooms]
    
    @staticmethod
    def get_all_rooms():
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM rooms")
        rooms = cur.fetchall()
        conn.close()
        return rooms
    
    @staticmethod
    def get_room_by_id(room_id):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM rooms WHERE room_id = ?", (room_id,))
        room = cur.fetchone()
        conn.close()
        return dict(room) if room else None

room = Room()

# ==================== BOOKING MODULE ====================
class Booking:
    @staticmethod
    def create_booking(user_id, room_id, check_in, check_out):
        try:
            conn = get_connection()
            cur = conn.cursor()
            
            # Lấy thông tin phòng
            cur.execute("SELECT price, status FROM rooms WHERE room_id = ?", (room_id,))
            result = cur.fetchone()
            
            if not result:
                conn.close()
                return False, "Room not found"
                
            price, room_status = result[0], result[1]
            
            # Kiểm tra phòng có sẵn không
            if room_status != 'available':
                conn.close()
                return False, "Room is not available"
            
            # Kiểm tra xem phòng có bị đặt trong khoảng thời gian này không
            cur.execute("""
                SELECT COUNT(*) FROM bookings 
                WHERE room_id = ? 
                AND status NOT IN ('cancelled')
                AND (
                    (check_in_date < ? AND check_out_date > ?) OR
                    (check_in_date >= ? AND check_out_date <= ?) OR
                    (check_in_date <= ? AND check_out_date >= ?)
                )
            """, (room_id, check_out, check_in, check_in, check_out, check_in, check_out))
            
            overlapping_bookings = cur.fetchone()[0]
            
            if overlapping_bookings > 0:
                conn.close()
                return False, "Room is already booked for these dates"
            
            # Tính số ngày và tổng tiền
            check_in_date = datetime.strptime(check_in, '%Y-%m-%d')
            check_out_date = datetime.strptime(check_out, '%Y-%m-%d')
            days = (check_out_date - check_in_date).days
            
            if days <= 0:
                conn.close()
                return False, "Check-out date must be after check-in date"
            
            total_price = price * days
            
            # Tạo booking
            cur.execute("""INSERT INTO bookings 
                          (user_id, room_id, check_in_date, check_out_date, total_price, status)
                          VALUES (?, ?, ?, ?, ?, 'pending')""",
                       (user_id, room_id, check_in, check_out, total_price))
            
            # Cập nhật trạng thái phòng
            cur.execute("UPDATE rooms SET status = 'booked' WHERE room_id = ?", (room_id,))
            
            conn.commit()
            booking_id = cur.lastrowid
            conn.close()
            return True, f"Booking successful! Booking ID: {booking_id}, Total: {total_price:,.0f} VND"
        except Exception as e:
            print(f"Booking error: {e}")
            return False, f"Error: {str(e)}"
    
    @staticmethod
    def get_user_bookings(user_id):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT b.booking_id, b.room_id, r.room_number, r.room_type,
                   b.check_in_date, b.check_out_date, b.status, b.total_price
            FROM bookings b
            JOIN rooms r ON b.room_id = r.room_id
            WHERE b.user_id = ?
            ORDER BY b.created_at DESC
        """, (user_id,))
        bookings = cur.fetchall()
        conn.close()
        return [tuple(b) for b in bookings]
    
    @staticmethod
    def get_all_bookings():
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT b.booking_id, u.full_name, r.room_number, 
                   b.check_in_date, b.check_out_date, b.status, b.total_price
            FROM bookings b
            JOIN users u ON b.user_id = u.user_id
            JOIN rooms r ON b.room_id = r.room_id
            ORDER BY b.created_at DESC
        """)
        bookings = cur.fetchall()
        conn.close()
        return bookings
    
    @staticmethod
    def cancel_booking(booking_id):
        try:
            conn = get_connection()
            cur = conn.cursor()
            
            cur.execute("SELECT room_id FROM bookings WHERE booking_id = ?", (booking_id,))
            result = cur.fetchone()
            
            if not result:
                conn.close()
                return False, "Booking not found"
                
            room_id = result[0]
            
            cur.execute("UPDATE bookings SET status = 'cancelled' WHERE booking_id = ?", (booking_id,))
            cur.execute("UPDATE rooms SET status = 'available' WHERE room_id = ?", (room_id,))
            
            conn.commit()
            conn.close()
            return True, "Booking cancelled successfully"
        except Exception as e:
            return False, f"Error: {str(e)}"

booking = Booking()

# ==================== PAYMENT MODULE ====================
class Payment:
    @staticmethod
    def create_payment(booking_id, amount, payment_method):
        try:
            conn = get_connection()
            cur = conn.cursor()
            
            # Kiểm tra booking
            cur.execute("SELECT status FROM bookings WHERE booking_id = ?", (booking_id,))
            result = cur.fetchone()
            
            if not result:
                conn.close()
                return False, "Booking not found"
                
            if result[0] == 'cancelled':
                conn.close()
                return False, "Cannot pay cancelled booking"
            
            cur.execute("""INSERT INTO payments (booking_id, amount, payment_method, status)
                          VALUES (?, ?, ?, 'completed')""",
                       (booking_id, amount, payment_method))
            
            cur.execute("UPDATE bookings SET status = 'paid' WHERE booking_id = ?", (booking_id,))
            
            conn.commit()
            conn.close()
            return True, "Payment completed successfully"
        except Exception as e:
            return False, f"Error: {str(e)}"
    
    @staticmethod
    def get_user_payments(user_id):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT p.payment_id, p.booking_id, p.amount, p.payment_method, 
                   p.payment_date, p.status
            FROM payments p
            JOIN bookings b ON p.booking_id = b.booking_id
            WHERE b.user_id = ?
            ORDER BY p.payment_date DESC
        """, (user_id,))
        payments = cur.fetchall()
        conn.close()
        return payments

payment = Payment()

# ==================== REVIEW MODULE ====================
class Review:
    @staticmethod
    def create_review(user_id, booking_id, rating, comment):
        try:
            conn = get_connection()
            cur = conn.cursor()
            
            # Kiểm tra xem booking đã thanh toán chưa
            cur.execute("SELECT status FROM bookings WHERE booking_id = ? AND user_id = ?", 
                       (booking_id, user_id))
            result = cur.fetchone()
            
            if not result:
                conn.close()
                return False, "Booking not found"
                
            if result[0] != 'paid':
                conn.close()
                return False, "Only paid bookings can be reviewed"
            
            cur.execute("""INSERT INTO reviews (user_id, booking_id, rating, comment)
                          VALUES (?, ?, ?, ?)""",
                       (user_id, booking_id, rating, comment))
            conn.commit()
            conn.close()
            return True, "Review submitted successfully"
        except Exception as e:
            return False, f"Error: {str(e)}"
    
    @staticmethod
    def get_user_reviews(user_id):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT r.review_id, r.booking_id, r.rating, r.comment, r.created_at
            FROM reviews r
            WHERE r.user_id = ?
            ORDER BY r.created_at DESC
        """, (user_id,))
        reviews = cur.fetchall()
        conn.close()
        return reviews

review = Review()

# ==================== MAIN UI CLASS ====================
class HotelManagementUI:
    def __init__(self, root):
        self.root = root
        self.root.title("🏨 Luxury Hotel")
        self.root.geometry("1200x700")
        
        self.current_user = None
        self.theme_mode = "light"
        
        self.apply_theme()
        self.create_directories()
        
        create_tables()
        seed_all()
        
        self.show_welcome_screen()
    
    def create_directories(self):
        directories = ['reports', 'backups']
        for directory in directories:
            if not os.path.exists(directory):
                os.makedirs(directory)
    
    def apply_theme(self):
        if self.theme_mode == "dark":
            self.bg_color = "#2C3E50"
            self.fg_color = "#ECF0F1"
            self.primary_color = "#3498DB"
            self.secondary_color = "#2980B9"
            self.success_color = "#2ECC71"
            self.warning_color = "#F39C12"
            self.danger_color = "#E74C3C"
        else:
            self.bg_color = "#F5F7FA"
            self.fg_color = "#2C3E50"
            self.primary_color = "#4A90E2"
            self.secondary_color = "#357ABD"
            self.success_color = "#27AE60"
            self.warning_color = "#F39C12"
            self.danger_color = "#C0392B"
        
        self.root.configure(bg=self.bg_color)
    
    def show_welcome_screen(self):
        self.clear_window()
        
        main_frame = tk.Frame(self.root, bg=self.bg_color)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        header_frame = tk.Frame(main_frame, bg=self.primary_color, height=100)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="🏨 LUXURY HOTEL", 
                font=("Arial", 28, "bold"), 
                bg=self.primary_color, fg="white").pack(pady=20)
        
        content_frame = tk.Frame(main_frame, bg=self.bg_color, padx=50, pady=30)
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(content_frame, 
                text="Welcome to Luxury Hotel",
                font=("Arial", 20, "bold"), 
                bg=self.bg_color, fg=self.fg_color).pack(pady=20)
        
        button_frame = tk.Frame(content_frame, bg=self.bg_color)
        button_frame.pack(pady=30)
        
        tk.Button(button_frame, text="🔐 Login", 
                 command=self.show_login_screen,
                 font=("Arial", 12, "bold"), 
                 bg=self.success_color, fg="white",
                 width=15, height=2, cursor="hand2").pack(side=tk.LEFT, padx=10)
        
        tk.Button(button_frame, text="📝 Register", 
                 command=self.show_register_screen,
                 font=("Arial", 12, "bold"), 
                 bg=self.primary_color, fg="white",
                 width=15, height=2, cursor="hand2").pack(side=tk.LEFT, padx=10)
        
        demo_frame = tk.LabelFrame(content_frame, text="Demo Accounts", 
                                  font=("Arial", 10, "bold"),
                                  bg=self.bg_color, fg=self.fg_color, 
                                  padx=20, pady=10)
        demo_frame.pack(pady=20)
        
        accounts = [
            "👑 Admin: admin@gmail.com / 123",
            "👤 Customer: customer@gmail.com / 123"
        ]
        
        for account in accounts:
            tk.Label(demo_frame, text=account, 
                    font=("Arial", 9), 
                    bg=self.bg_color, fg=self.fg_color).pack(anchor="w", pady=2)
    
    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()
    
    def show_login_screen(self):
        self.clear_window()
        
        main_container = tk.Frame(self.root, bg=self.bg_color)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        left_panel = tk.Frame(main_container, bg=self.primary_color, width=400)
        left_panel.pack(side=tk.LEFT, fill=tk.Y)
        left_panel.pack_propagate(False)
        
        tk.Label(left_panel, text="🏨", 
                font=("Arial", 80), 
                bg=self.primary_color, fg="white").pack(pady=50)
        tk.Label(left_panel, text="Welcome Back", 
                font=("Arial", 24, "bold"),
                bg=self.primary_color, fg="white").pack(pady=10)
        
        right_panel = tk.Frame(main_container, bg=self.bg_color)
        right_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=50, pady=50)
        
        tk.Button(right_panel, text="← Back", 
                 command=self.show_welcome_screen,
                 font=("Arial", 10), 
                 bg=self.bg_color, fg=self.primary_color,
                 borderwidth=0, cursor="hand2").pack(anchor=tk.NW, pady=(0, 20))
        
        form_frame = tk.Frame(right_panel, bg=self.bg_color)
        form_frame.pack(expand=True)
        
        tk.Label(form_frame, text="Login to Your Account", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=(0, 30))
        
        tk.Label(form_frame, text="Email Address", 
                font=("Arial", 11, "bold"),
                bg=self.bg_color, fg=self.fg_color, 
                anchor="w").pack(fill=tk.X, pady=(10, 5))
        email_entry = ttk.Entry(form_frame, font=("Arial", 12), width=35)
        email_entry.pack(pady=(0, 15))
        email_entry.insert(0, "customer@gmail.com")
        
        tk.Label(form_frame, text="Password", 
                font=("Arial", 11, "bold"),
                bg=self.bg_color, fg=self.fg_color, 
                anchor="w").pack(fill=tk.X, pady=(10, 5))
        password_entry = ttk.Entry(form_frame, font=("Arial", 12), width=35, show="•")
        password_entry.pack(pady=(0, 10))
        password_entry.insert(0, "123")
        
        def login_action():
            email = email_entry.get().strip()
            password = password_entry.get().strip()
            
            if not email or not password:
                messagebox.showerror("Error", "Please enter both email and password!")
                return
            
            user = auth.login(email, password)
            if user:
                self.current_user = user
                if user['role'] == 'admin':
                    self.show_admin_screen()
                else:
                    self.show_customer_screen()
            else:
                messagebox.showerror("Error", "Incorrect email or password!")
        
        tk.Button(form_frame, text="🔐 Login", 
                 command=login_action,
                 font=("Arial", 12, "bold"),
                 bg=self.primary_color, fg="white",
                 width=25, height=2, cursor="hand2").pack(pady=20)
        
        tk.Label(form_frame, text="Don't have an account?", 
                font=("Arial", 10),
                bg=self.bg_color, fg=self.fg_color).pack(pady=(20, 5))
        tk.Button(form_frame, text="Create Account", 
                 command=self.show_register_screen,
                 font=("Arial", 10, "bold"), 
                 bg=self.bg_color, fg=self.success_color,
                 borderwidth=0, cursor="hand2").pack()
    
    def show_register_screen(self):
        self.clear_window()
        
        main_frame = tk.Frame(self.root, bg=self.bg_color)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=50, pady=30)
        
        tk.Button(main_frame, text="← Back", 
                 command=self.show_welcome_screen,
                 font=("Arial", 10), 
                 bg=self.bg_color, fg=self.primary_color,
                 borderwidth=0, cursor="hand2").pack(anchor=tk.NW)
        
        form_container = tk.Frame(main_frame, bg=self.bg_color)
        form_container.pack(expand=True)
        
        tk.Label(form_container, text="Create New Account", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=(0, 30))
        
        entries = {}
        fields = [
            ("Full Name", "name"),
            ("Email Address", "email"),
            ("Phone Number", "phone"),
            ("Password", "password"),
            ("Confirm Password", "confirm_password")
        ]
        
        for label_text, key in fields:
            tk.Label(form_container, text=label_text, 
                    font=("Arial", 11, "bold"),
                    bg=self.bg_color, fg=self.fg_color, 
                    anchor="w").pack(fill=tk.X, pady=(15, 5))
            show_char = "" if "Password" not in label_text else "•"
            entry = ttk.Entry(form_container, font=("Arial", 12), width=40, show=show_char)
            entry.pack(pady=(0, 10))
            entries[key] = entry
        
        def register_action():
            values = {k: entries[k].get().strip() for k in entries}
            
            if not all(values.values()):
                messagebox.showerror("Error", "All fields are required!")
                return
            
            if '@' not in values['email']:
                messagebox.showerror("Error", "Invalid email!")
                return
            
            if len(values['password']) < 3:
                messagebox.showerror("Error", "Password too short!")
                return
            
            if values['password'] != values['confirm_password']:
                messagebox.showerror("Error", "Passwords do not match!")
                return
            
            if auth.register(values['name'], values['email'], values['password'], values['phone']):
                messagebox.showinfo("Success", "Registration successful! Please login.")
                self.show_login_screen()
            else:
                messagebox.showerror("Error", "Email already exists!")
        
        tk.Button(form_container, text="📝 Create Account", 
                 command=register_action,
                 font=("Arial", 12, "bold"),
                 bg=self.success_color, fg="white",
                 width=25, height=2, cursor="hand2").pack(pady=20)
    
    def show_customer_screen(self):
        self.clear_window()
        
        main_container = tk.Frame(self.root, bg=self.bg_color)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        sidebar = tk.Frame(main_container, bg=self.primary_color, width=250)
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)
        
        user_info_frame = tk.Frame(sidebar, bg=self.secondary_color, height=120)
        user_info_frame.pack(fill=tk.X, pady=(0, 20))
        user_info_frame.pack_propagate(False)
        
        tk.Label(user_info_frame, text="👤", 
                font=("Arial", 40), 
                bg=self.secondary_color, fg="white").pack(pady=(20, 5))
        tk.Label(user_info_frame, text=self.current_user['full_name'], 
                font=("Arial", 12, "bold"), 
                bg=self.secondary_color, fg="white").pack(pady=5)
        
        nav_items = [
            ("🏠 Dashboard", self.show_customer_dashboard),
            ("🛏️ Browse Rooms", self.show_rooms_tab),
            ("📅 My Bookings", self.show_bookings_tab),
            ("💰 Payments", self.show_payments_tab),
            ("⭐ Reviews", self.show_reviews_tab),
            ("🔓 Logout", self.show_login_screen)
        ]
        
        for text, command in nav_items:
            btn = tk.Button(sidebar, text=text, command=command,
                           font=("Arial", 11), bg=self.primary_color, fg="white",
                           anchor="w", borderwidth=0, padx=20, pady=12, 
                           cursor="hand2", activebackground=self.secondary_color)
            btn.pack(fill=tk.X, padx=10, pady=2)
        
        self.content_area = tk.Frame(main_container, bg=self.bg_color)
        self.content_area.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        self.show_customer_dashboard()
    
    def show_customer_dashboard(self):
        self.clear_content_area()
        
        tk.Label(self.content_area, text="Customer Dashboard", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        conn = get_connection()
        cur = conn.cursor()
        
        cur.execute("SELECT COUNT(*) FROM bookings WHERE user_id = ?", 
                   (self.current_user['user_id'],))
        total_bookings = cur.fetchone()[0]
        
        cur.execute("SELECT COUNT(*) FROM bookings WHERE user_id = ? AND status = 'paid'", 
                   (self.current_user['user_id'],))
        paid_bookings = cur.fetchone()[0]
        
        cur.execute("SELECT COUNT(*) FROM reviews WHERE user_id = ?", 
                   (self.current_user['user_id'],))
        total_reviews = cur.fetchone()[0]
        
        conn.close()
        
        stats_frame = tk.Frame(self.content_area, bg=self.bg_color)
        stats_frame.pack(fill=tk.X, padx=30, pady=20)
        
        stats_cards = [
            ("📅 Total Bookings", total_bookings, self.primary_color),
            ("💰 Paid Bookings", paid_bookings, self.success_color),
            ("⭐ My Reviews", total_reviews, self.warning_color)
        ]
        
        for text, value, color in stats_cards:
            card = tk.Frame(stats_frame, bg=color, width=200, height=120)
            card.pack_propagate(False)
            card.pack(side=tk.LEFT, padx=10, pady=10)
            
            tk.Label(card, text=text, font=("Arial", 12, "bold"), 
                    bg=color, fg="white").pack(pady=(20, 5))
            tk.Label(card, text=str(value), font=("Arial", 24, "bold"), 
                    bg=color, fg="white").pack(pady=(5, 20))
        
        actions_frame = tk.LabelFrame(self.content_area, text="Quick Actions", 
                                     font=("Arial", 14, "bold"),
                                     bg=self.bg_color, fg=self.fg_color, 
                                     padx=20, pady=20)
        actions_frame.pack(fill=tk.X, padx=30, pady=20)
        
        tk.Button(actions_frame, text="🛏️ Book a Room", 
                 command=self.show_rooms_tab,
                 font=("Arial", 11), bg=self.secondary_color, fg="white",
                 width=20, height=2, cursor="hand2").pack(side=tk.LEFT, padx=10)
        
        tk.Button(actions_frame, text="📅 View Bookings", 
                 command=self.show_bookings_tab,
                 font=("Arial", 11), bg=self.secondary_color, fg="white",
                 width=20, height=2, cursor="hand2").pack(side=tk.LEFT, padx=10)
    
    def show_rooms_tab(self):
        self.clear_content_area()
        
        tk.Label(self.content_area, text="Available Rooms", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        # Create a main frame
        main_frame = tk.Frame(self.content_area, bg=self.bg_color)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # Create a canvas for scrolling
        canvas = tk.Canvas(main_frame, bg=self.bg_color, highlightthickness=0)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        
        # Create a frame inside the canvas
        rooms_frame = tk.Frame(canvas, bg=self.bg_color)
        
        # Configure the canvas
        rooms_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=rooms_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Load available rooms
        rooms = room.get_available_rooms()
        
        if not rooms:
            tk.Label(rooms_frame, text="No rooms available at the moment", 
                    font=("Arial", 14),
                    bg=self.bg_color, fg=self.fg_color).pack(pady=50)
        else:
            # Display rooms in a grid
            for i, room_data in enumerate(rooms):
                row = i // 3
                col = i % 3
                
                room_card = self.create_room_card(rooms_frame, room_data)
                room_card.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Enable mouse wheel scrolling
        def on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
        canvas.bind_all("<MouseWheel>", on_mousewheel)
    
    def create_room_card(self, parent, room_data):
        """Tạo card hiển thị phòng"""
        room_id, room_number, room_type, price, status = room_data
        
        card = tk.Frame(parent, bg="white", width=300, height=350,
                       relief=tk.RAISED, borderwidth=2)
        card.pack_propagate(False)
        
        # Room header
        header = tk.Frame(card, bg=self.primary_color, height=60)
        header.pack(fill=tk.X)
        
        tk.Label(header, text=f"Room {room_number}", 
                font=("Arial", 14, "bold"),
                bg=self.primary_color, fg="white").pack(pady=10)
        
        # Room details
        details = tk.Frame(card, bg="white", padx=20, pady=15)
        details.pack(fill=tk.BOTH, expand=True)
        
        # Room type with icon
        type_frame = tk.Frame(details, bg="white")
        type_frame.pack(fill=tk.X, pady=(0, 10))
        
        icon = "🛏️" if room_type == "Standard" else "🌟" if room_type == "Deluxe" else "🏰" if room_type == "Suite" else "👑"
        tk.Label(type_frame, text=f"{icon} {room_type}", 
                font=("Arial", 13, "bold"),
                bg="white", fg="#333").pack(side=tk.LEFT)
        
        # Price
        price_frame = tk.Frame(details, bg="white")
        price_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(price_frame, text=f"💵 {price:,.0f} VND/night", 
                font=("Arial", 11),
                bg="white", fg="#666").pack(side=tk.LEFT)
        
        # Status
        status_frame = tk.Frame(details, bg="white")
        status_frame.pack(fill=tk.X, pady=(0, 15))
        
        status_color = self.success_color if status == "available" else self.warning_color
        tk.Label(status_frame, text=f"● {status.upper()}", 
                font=("Arial", 10, "bold"),
                bg="white", fg=status_color).pack(side=tk.LEFT)
        
        # Separator
        separator = tk.Frame(details, height=1, bg="#E0E0E0")
        separator.pack(fill=tk.X, pady=(0, 15))
        
        # Booking form
        booking_frame = tk.Frame(details, bg="white")
        booking_frame.pack(fill=tk.X)
        
        # Check-in date
        checkin_frame = tk.Frame(booking_frame, bg="white")
        checkin_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(checkin_frame, text="Check-in:", 
                font=("Arial", 10),
                bg="white", width=10).pack(side=tk.LEFT)
        
        checkin_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        checkin_entry = ttk.Entry(checkin_frame, textvariable=checkin_var, 
                                 width=15, font=("Arial", 10))
        checkin_entry.pack(side=tk.LEFT)
        
        # Check-out date
        checkout_frame = tk.Frame(booking_frame, bg="white")
        checkout_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(checkout_frame, text="Check-out:", 
                font=("Arial", 10),
                bg="white", width=10).pack(side=tk.LEFT)
        
        checkout_var = tk.StringVar(value=(datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d"))
        checkout_entry = ttk.Entry(checkout_frame, textvariable=checkout_var, 
                                  width=15, font=("Arial", 10))
        checkout_entry.pack(side=tk.LEFT)
        
        def book_room():
            checkin = checkin_var.get().strip()
            checkout = checkout_var.get().strip()
            
            if not checkin or not checkout:
                messagebox.showerror("Error", "Please enter both check-in and check-out dates!")
                return
            
            try:
                # Validate date format
                datetime.strptime(checkin, "%Y-%m-%d")
                datetime.strptime(checkout, "%Y-%m-%d")
            except ValueError:
                messagebox.showerror("Error", "Invalid date format! Please use YYYY-MM-DD")
                return
            
            # Show confirmation dialog
            confirm = messagebox.askyesno("Confirm Booking", 
                                         f"Book Room {room_number}?\n"
                                         f"Check-in: {checkin}\n"
                                         f"Check-out: {checkout}\n"
                                         f"Type: {room_type}\n"
                                         f"Price: {price:,.0f} VND/night")
            
            if confirm:
                success, message = booking.create_booking(
                    self.current_user['user_id'], 
                    room_id, 
                    checkin, 
                    checkout
                )
                
                if success:
                    messagebox.showinfo("Success", message)
                    self.show_rooms_tab()  # Refresh the room list
                else:
                    messagebox.showerror("Booking Failed", message)
        
        # Book button
        book_btn = tk.Button(details, text="📅 Book Now", 
                           command=book_room,
                           font=("Arial", 11, "bold"),
                           bg=self.success_color, fg="white",
                           width=20, height=2, cursor="hand2",
                           activebackground="#2ECC71")
        book_btn.pack(pady=(10, 5))
        
        return card
    
    def show_bookings_tab(self):
        """Hiển thị tab bookings"""
        self.clear_content_area()
        
        tk.Label(self.content_area, text="My Bookings", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        # Toolbar
        toolbar = tk.Frame(self.content_area, bg=self.bg_color)
        toolbar.pack(fill=tk.X, padx=30, pady=(0, 20))
        
        tk.Button(toolbar, text="🔄 Refresh", 
                 command=self.show_bookings_tab,
                 font=("Arial", 10),
                 bg=self.primary_color, fg="white",
                 cursor="hand2").pack(side=tk.LEFT, padx=5)
        
        # Bookings table
        table_frame = tk.Frame(self.content_area, bg=self.bg_color)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=10)
        
        columns = ("Booking ID", "Room", "Type", "Check-in", "Check-out", "Status", "Amount")
        tree = ttk.Treeview(table_frame, columns=columns, height=15, show='tree headings')
        
        tree.column("#0", width=0, stretch=tk.NO)
        widths = [80, 80, 100, 100, 100, 80, 100]
        for col, width in zip(columns, widths):
            tree.column(col, anchor=tk.W, width=width)
            tree.heading(col, text=col, anchor=tk.W)
        
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load bookings
        bookings = booking.get_user_bookings(self.current_user['user_id'])
        for b in bookings:
            booking_id, room_id, room_number, room_type, check_in, check_out, status, amount = b
            
            # Set color for status
            status_color = ""
            if status == "pending":
                status_color = self.warning_color
            elif status == "paid":
                status_color = self.success_color
            elif status == "cancelled":
                status_color = self.danger_color
            
            tree.insert("", "end", values=(
                booking_id, 
                room_number,
                room_type,
                check_in, 
                check_out, 
                status, 
                f"{amount:,.0f} VND"
            ))
        
        # Action buttons
        action_frame = tk.Frame(self.content_area, bg=self.bg_color)
        action_frame.pack(pady=20)
        
        def cancel_selected():
            selection = tree.selection()
            if not selection:
                messagebox.showerror("Error", "Please select a booking!")
                return
            
            item = tree.item(selection[0])
            booking_id = item['values'][0]
            status = item['values'][5]
            
            if status == "cancelled":
                messagebox.showinfo("Info", "This booking is already cancelled!")
                return
            
            if status == "paid":
                if not messagebox.askyesno("Confirm", "This booking is already paid. Cancel anyway?"):
                    return
            
            if messagebox.askyesno("Confirm Cancellation", "Are you sure you want to cancel this booking?"):
                success, message = booking.cancel_booking(booking_id)
                if success:
                    messagebox.showinfo("Success", message)
                    self.show_bookings_tab()
                else:
                    messagebox.showerror("Error", message)
        
        def pay_selected():
            selection = tree.selection()
            if not selection:
                messagebox.showerror("Error", "Please select a booking!")
                return
            
            item = tree.item(selection[0])
            booking_id = item['values'][0]
            status = item['values'][5]
            amount_str = item['values'][6]
            
            if status == "paid":
                messagebox.showinfo("Info", "This booking is already paid!")
                return
            
            if status == "cancelled":
                messagebox.showerror("Error", "Cannot pay cancelled booking!")
                return
            
            # Extract amount from string
            try:
                amount = float(amount_str.replace(" VND", "").replace(",", ""))
            except:
                messagebox.showerror("Error", "Invalid amount!")
                return
            
            self.open_payment_window(booking_id, amount)
        
        def review_selected():
            selection = tree.selection()
            if not selection:
                messagebox.showerror("Error", "Please select a booking!")
                return
            
            item = tree.item(selection[0])
            booking_id = item['values'][0]
            status = item['values'][5]
            
            if status != "paid":
                messagebox.showwarning("Warning", "Only paid bookings can be reviewed!")
                return
            
            self.open_review_window(booking_id)
        
        tk.Button(action_frame, text="Cancel Booking", 
                 command=cancel_selected,
                 font=("Arial", 11),
                 bg=self.warning_color, fg="white",
                 width=15, cursor="hand2").pack(side=tk.LEFT, padx=10)
        
        tk.Button(action_frame, text="Make Payment", 
                 command=pay_selected,
                 font=("Arial", 11),
                 bg=self.success_color, fg="white",
                 width=15, cursor="hand2").pack(side=tk.LEFT, padx=10)
        
        tk.Button(action_frame, text="Write Review", 
                 command=review_selected,
                 font=("Arial", 11),
                 bg=self.primary_color, fg="white",
                 width=15, cursor="hand2").pack(side=tk.LEFT, padx=10)
    
    def open_payment_window(self, booking_id, amount):
        """Mở cửa sổ thanh toán"""
        pay_win = tk.Toplevel(self.root)
        pay_win.title("Payment")
        pay_win.geometry("400x350")
        pay_win.configure(bg=self.bg_color)
        pay_win.grab_set()
        
        # Center window
        pay_win.update_idletasks()
        x = (pay_win.winfo_screenwidth() - pay_win.winfo_reqwidth()) // 2
        y = (pay_win.winfo_screenheight() - pay_win.winfo_reqheight()) // 2
        pay_win.geometry(f"+{x}+{y}")
        
        tk.Label(pay_win, text="💳 Payment", 
                font=("Arial", 18, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=20)
        
        info_frame = tk.Frame(pay_win, bg=self.bg_color)
        info_frame.pack(pady=10)
        
        tk.Label(info_frame, text=f"Booking ID: #{booking_id}", 
                font=("Arial", 12),
                bg=self.bg_color, fg=self.fg_color).pack(pady=5)
        
        tk.Label(info_frame, text=f"Amount: {amount:,.0f} VND", 
                font=("Arial", 14, "bold"),
                bg=self.bg_color, fg=self.primary_color).pack(pady=10)
        
        # Payment method
        method_frame = tk.LabelFrame(pay_win, text="Payment Method", 
                                    font=("Arial", 11, "bold"),
                                    bg=self.bg_color, fg=self.fg_color,
                                    padx=15, pady=10)
        method_frame.pack(pady=15, padx=20, fill=tk.X)
        
        method_var = tk.StringVar(value="Cash")
        
        methods = ["Cash", "Bank Transfer", "Credit Card", "E-Wallet"]
        for method in methods:
            tk.Radiobutton(method_frame, text=method, 
                          variable=method_var, value=method,
                          font=("Arial", 10),
                          bg=self.bg_color, fg=self.fg_color).pack(anchor=tk.W, pady=2)
        
        def confirm_payment():
            success, message = payment.create_payment(booking_id, amount, method_var.get())
            if success:
                messagebox.showinfo("Success", message)
                pay_win.destroy()
                self.show_bookings_tab()
            else:
                messagebox.showerror("Error", message)
        
        tk.Button(pay_win, text="Confirm Payment", 
                 command=confirm_payment,
                 font=("Arial", 11, "bold"),
                 bg=self.success_color, fg="white",
                 width=20, cursor="hand2").pack(pady=20)
    
    def open_review_window(self, booking_id):
        """Mở cửa sổ viết review"""
        review_win = tk.Toplevel(self.root)
        review_win.title("Write Review")
        review_win.geometry("500x450")
        review_win.configure(bg=self.bg_color)
        review_win.grab_set()
        
        # Center window
        review_win.update_idletasks()
        x = (review_win.winfo_screenwidth() - review_win.winfo_reqwidth()) // 2
        y = (review_win.winfo_screenheight() - review_win.winfo_reqheight()) // 2
        review_win.geometry(f"+{x}+{y}")
        
        tk.Label(review_win, text="⭐ Write Review", 
                font=("Arial", 18, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=20)
        
        tk.Label(review_win, text=f"Booking ID: #{booking_id}", 
                font=("Arial", 12),
                bg=self.bg_color, fg=self.fg_color).pack(pady=5)
        
        # Rating
        rating_frame = tk.Frame(review_win, bg=self.bg_color)
        rating_frame.pack(pady=15)
        
        tk.Label(rating_frame, text="Rating:", 
                font=("Arial", 11, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(side=tk.LEFT, padx=(0, 10))
        
        rating_var = tk.IntVar(value=5)
        
        for i in range(1, 6):
            tk.Radiobutton(rating_frame, text=f"{i}★", 
                          variable=rating_var, value=i,
                          font=("Arial", 12),
                          bg=self.bg_color, fg=self.fg_color).pack(side=tk.LEFT, padx=5)
        
        # Comment
        comment_frame = tk.LabelFrame(review_win, text="Comment", 
                                     font=("Arial", 11, "bold"),
                                     bg=self.bg_color, fg=self.fg_color,
                                     padx=15, pady=10)
        comment_frame.pack(pady=15, padx=20, fill=tk.BOTH, expand=True)
        
        comment_text = scrolledtext.ScrolledText(comment_frame, 
                                                font=("Arial", 10),
                                                height=8,
                                                bg="#F8F9FA", fg="#333")
        comment_text.pack(fill=tk.BOTH, expand=True)
        
        def submit_review():
            rating = rating_var.get()
            comment = comment_text.get("1.0", tk.END).strip()
            
            if not comment:
                messagebox.showerror("Error", "Please write a comment!")
                return
            
            success, message = review.create_review(self.current_user['user_id'], booking_id, rating, comment)
            if success:
                messagebox.showinfo("Success", message)
                review_win.destroy()
                self.show_bookings_tab()
            else:
                messagebox.showerror("Error", message)
        
        tk.Button(review_win, text="Submit Review", 
                 command=submit_review,
                 font=("Arial", 11, "bold"),
                 bg=self.success_color, fg="white",
                 width=15, cursor="hand2").pack(pady=20)
    
    def show_payments_tab(self):
        """Hiển thị tab payments"""
        self.clear_content_area()
        
        tk.Label(self.content_area, text="Payment History", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        table_frame = tk.Frame(self.content_area, bg=self.bg_color)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        columns = ("Payment ID", "Booking ID", "Amount", "Method", "Date", "Status")
        tree = ttk.Treeview(table_frame, columns=columns, height=12, show='tree headings')
        
        tree.column("#0", width=0, stretch=tk.NO)
        widths = [80, 80, 100, 100, 120, 80]
        for col, width in zip(columns, widths):
            tree.column(col, anchor=tk.W, width=width)
            tree.heading(col, text=col, anchor=tk.W)
        
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load payments
        payments = payment.get_user_payments(self.current_user['user_id'])
        for p in payments:
            payment_id, booking_id, amount, method, date, status = p
            tree.insert("", "end", values=(
                payment_id,
                booking_id,
                f"{amount:,.0f} VND",
                method,
                date,
                status
            ))
    
    def show_reviews_tab(self):
        """Hiển thị tab reviews"""
        self.clear_content_area()
        
        tk.Label(self.content_area, text="My Reviews", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        table_frame = tk.Frame(self.content_area, bg=self.bg_color)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        columns = ("Review ID", "Booking ID", "Rating", "Comment", "Date")
        tree = ttk.Treeview(table_frame, columns=columns, height=12, show='tree headings')
        
        tree.column("#0", width=0, stretch=tk.NO)
        widths = [80, 80, 60, 200, 100]
        for col, width in zip(columns, widths):
            tree.column(col, anchor=tk.W, width=width)
            tree.heading(col, text=col, anchor=tk.W)
        
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load reviews
        reviews = review.get_user_reviews(self.current_user['user_id'])
        for r in reviews:
            review_id, booking_id, rating, comment, date = r
            
            # Truncate comment if too long
            display_comment = comment
            if len(comment) > 50:
                display_comment = comment[:50] + "..."
            
            # Format rating with stars
            stars = "★" * rating + "☆" * (5 - rating)
            
            tree.insert("", "end", values=(
                review_id,
                booking_id,
                stars,
                display_comment,
                date[:10]  # Only show date
            ))
    
    def clear_content_area(self):
        """Xóa nội dung content area"""
        for widget in self.content_area.winfo_children():
            widget.destroy()
    
    def show_admin_screen(self):
        """Hiển thị màn hình admin"""
        self.clear_window()
        
        main_container = tk.Frame(self.root, bg=self.bg_color)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        sidebar = tk.Frame(main_container, bg=self.primary_color, width=280)
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)
        
        # Admin header
        admin_header = tk.Frame(sidebar, bg=self.secondary_color, height=150)
        admin_header.pack(fill=tk.X, pady=(0, 20))
        admin_header.pack_propagate(False)
        
        tk.Label(admin_header, text="👑", 
                font=("Arial", 50),
                bg=self.secondary_color, fg="white").pack(pady=(20, 5))
        tk.Label(admin_header, text="ADMIN PANEL", 
                font=("Arial", 14, "bold"),
                bg=self.secondary_color, fg="white").pack(pady=5)
        tk.Label(admin_header, text=self.current_user['full_name'], 
                font=("Arial", 11),
                bg=self.secondary_color, fg="white").pack()
        
        # Admin navigation
        admin_nav = [
            ("📊 Dashboard", self.show_admin_dashboard),
            ("🏨 Manage Rooms", self.show_admin_rooms),
            ("📅 Manage Bookings", self.show_admin_bookings),
            ("💰 Manage Payments", self.show_admin_payments),
            ("⭐ Manage Reviews", self.show_admin_reviews),
            ("👥 Manage Users", self.show_admin_users),
            ("📈 Analytics", self.show_admin_analytics),
            ("🔓 Logout", self.show_login_screen)
        ]
        
        for text, command in admin_nav:
            btn = tk.Button(sidebar, text=text, command=command,
                           font=("Arial", 11), bg=self.primary_color, fg="white",
                           anchor="w", borderwidth=0, padx=25, pady=12, 
                           cursor="hand2", activebackground=self.secondary_color)
            btn.pack(fill=tk.X, padx=10, pady=2)
        
        self.admin_content = tk.Frame(main_container, bg=self.bg_color)
        self.admin_content.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        self.show_admin_dashboard()
    
    def show_admin_dashboard(self):
        """Hiển thị dashboard admin"""
        self.clear_admin_content()
        
        tk.Label(self.admin_content, text="Admin Dashboard", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        conn = get_connection()
        cur = conn.cursor()
        
        # Get stats
        cur.execute("SELECT COUNT(*) FROM users")
        total_users = cur.fetchone()[0]
        
        cur.execute("SELECT COUNT(*) FROM rooms")
        total_rooms = cur.fetchone()[0]
        
        cur.execute("SELECT COUNT(*) FROM bookings WHERE status = 'paid'")
        active_bookings = cur.fetchone()[0]
        
        cur.execute("SELECT SUM(total_price) FROM bookings WHERE status = 'paid'")
        total_revenue = cur.fetchone()[0] or 0
        
        cur.execute("SELECT COUNT(*) FROM bookings WHERE status = 'pending'")
        pending_bookings = cur.fetchone()[0]
        
        cur.execute("SELECT COUNT(*) FROM reviews")
        total_reviews = cur.fetchone()[0]
        
        conn.close()
        
        # Stats cards
        stats_frame = tk.Frame(self.admin_content, bg=self.bg_color)
        stats_frame.pack(fill=tk.X, padx=30, pady=20)
        
        stats_data = [
            ("👥 Total Users", total_users, self.primary_color),
            ("🏨 Total Rooms", total_rooms, self.success_color),
            ("📅 Active Bookings", active_bookings, self.warning_color),
            ("💰 Total Revenue", f"{total_revenue:,.0f} VND", self.primary_color),
            ("⏳ Pending", pending_bookings, "#9B59B6"),
            ("⭐ Reviews", total_reviews, "#3498DB")
        ]
        
        row, col = 0, 0
        for text, value, color in stats_data:
            card = tk.Frame(stats_frame, bg=color, width=200, height=150)
            card.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
            card.pack_propagate(False)
            
            tk.Label(card, text=text, font=("Arial", 12, "bold"), 
                    bg=color, fg="white").pack(pady=(25, 10))
            tk.Label(card, text=str(value), font=("Arial", 22, "bold"), 
                    bg=color, fg="white").pack()
            
            col += 1
            if col > 2:
                col = 0
                row += 1
        
        # Recent bookings
        bookings_frame = tk.LabelFrame(self.admin_content, text="Recent Bookings", 
                                      font=("Arial", 14, "bold"),
                                      bg=self.bg_color, fg=self.fg_color,
                                      padx=20, pady=20)
        bookings_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        # Treeview for recent bookings
        columns = ("ID", "Customer", "Room", "Check-in", "Check-out", "Status", "Amount")
        tree = ttk.Treeview(bookings_frame, columns=columns, height=8)
        
        tree.column("#0", width=0, stretch=tk.NO)
        widths = [60, 100, 60, 90, 90, 80, 90]
        for col, width in zip(columns, widths):
            tree.column(col, anchor=tk.W, width=width)
            tree.heading(col, text=col, anchor=tk.W)
        
        scrollbar = ttk.Scrollbar(bookings_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load recent bookings
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT b.booking_id, u.full_name, r.room_number, 
                   b.check_in_date, b.check_out_date, b.status, b.total_price
            FROM bookings b
            JOIN users u ON b.user_id = u.user_id
            JOIN rooms r ON b.room_id = r.room_id
            ORDER BY b.created_at DESC LIMIT 10
        """)
        recent = cur.fetchall()
        conn.close()
        
        for b in recent:
            booking_id, customer, room, checkin, checkout, status, amount = b
            tree.insert("", "end", values=(
                booking_id, customer, room, checkin, checkout, status, f"{amount:,.0f} VND"
            ))
    
    def show_admin_rooms(self):
        """Quản lý phòng - Admin"""
        self.clear_admin_content()
        
        tk.Label(self.admin_content, text="Manage Rooms", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        toolbar = tk.Frame(self.admin_content, bg=self.bg_color)
        toolbar.pack(fill=tk.X, padx=30, pady=(0, 20))
        
        tk.Button(toolbar, text="Add Room", 
                 command=self.show_add_room,
                 font=("Arial", 10),
                 bg=self.success_color, fg="white",
                 cursor="hand2").pack(side=tk.LEFT, padx=5)
        
        # Rooms table
        table_frame = tk.Frame(self.admin_content, bg=self.bg_color)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=10)
        
        columns = ("ID", "Room #", "Type", "Price", "Status")
        tree = ttk.Treeview(table_frame, columns=columns, height=15, show='tree headings')
        
        tree.column("#0", width=0, stretch=tk.NO)
        widths = [50, 80, 100, 100, 80]
        for col, width in zip(columns, widths):
            tree.column(col, anchor=tk.W, width=width)
            tree.heading(col, text=col, anchor=tk.W)
        
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load rooms
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT room_id, room_number, room_type, price, status FROM rooms")
        rooms = cur.fetchall()
        conn.close()
        
        for r in rooms:
            room_id, room_number, room_type, price, status = r
            tree.insert("", "end", values=(
                room_id,
                room_number,
                room_type,
                f"{price:,.0f} VND",
                status
            ))
        
        # Action buttons
        action_frame = tk.Frame(self.admin_content, bg=self.bg_color)
        action_frame.pack(pady=20)
        
        def update_status():
            selection = tree.selection()
            if not selection:
                messagebox.showerror("Error", "Select a room!")
                return
            
            item = tree.item(selection[0])
            room_id = item['values'][0]
            
            status_win = tk.Toplevel(self.root)
            status_win.title("Update Status")
            status_win.geometry("300x200")
            status_win.configure(bg=self.bg_color)
            status_win.grab_set()
            
            tk.Label(status_win, text="New Status:", 
                    font=("Arial", 11),
                    bg=self.bg_color, fg=self.fg_color).pack(pady=20)
            
            status_var = tk.StringVar(value="available")
            status_combo = ttk.Combobox(status_win, textvariable=status_var,
                                       values=["available", "booked", "maintenance"],
                                       state="readonly")
            status_combo.pack(pady=10)
            
            def save_status():
                conn = get_connection()
                cur = conn.cursor()
                cur.execute("UPDATE rooms SET status = ? WHERE room_id = ?", 
                           (status_var.get(), room_id))
                conn.commit()
                conn.close()
                messagebox.showinfo("Success", "Status updated!")
                status_win.destroy()
                self.show_admin_rooms()
            
            tk.Button(status_win, text="Save", 
                     command=save_status,
                     font=("Arial", 10, "bold"),
                     bg=self.success_color, fg="white",
                     width=10, cursor="hand2").pack(pady=20)
        
        def edit_room():
            selection = tree.selection()
            if not selection:
                messagebox.showerror("Error", "Select a room!")
                return
            
            item = tree.item(selection[0])
            room_id = item['values'][0]
            room_number = item['values'][1]
            room_type = item['values'][2]
            price = item['values'][3]
            status = item['values'][4]
            
            # Open edit window
            edit_win = tk.Toplevel(self.root)
            edit_win.title("Edit Room")
            edit_win.geometry("400x350")
            edit_win.configure(bg=self.bg_color)
            edit_win.grab_set()
            
            tk.Label(edit_win, text="Edit Room", 
                    font=("Arial", 18, "bold"),
                    bg=self.bg_color, fg=self.fg_color).pack(pady=20)
            
            # Remove " VND" from price
            price_value = price.replace(" VND", "").replace(",", "")
            
            fields = tk.Frame(edit_win, bg=self.bg_color)
            fields.pack(pady=20, padx=30)
            
            tk.Label(fields, text="Room Number:", 
                    font=("Arial", 10),
                    bg=self.bg_color, fg=self.fg_color).grid(row=0, column=0, sticky="w", pady=5)
            room_num_entry = ttk.Entry(fields, width=20)
            room_num_entry.grid(row=0, column=1, pady=5, padx=10)
            room_num_entry.insert(0, room_number)
            
            tk.Label(fields, text="Room Type:", 
                    font=("Arial", 10),
                    bg=self.bg_color, fg=self.fg_color).grid(row=1, column=0, sticky="w", pady=5)
            type_combo = ttk.Combobox(fields, values=["Standard", "Deluxe", "Suite", "VIP"], width=18)
            type_combo.grid(row=1, column=1, pady=5, padx=10)
            type_combo.set(room_type)
            
            tk.Label(fields, text="Price:", 
                    font=("Arial", 10),
                    bg=self.bg_color, fg=self.fg_color).grid(row=2, column=0, sticky="w", pady=5)
            price_entry = ttk.Entry(fields, width=20)
            price_entry.grid(row=2, column=1, pady=5, padx=10)
            price_entry.insert(0, price_value)
            
            def save_changes():
                new_room_num = room_num_entry.get().strip()
                new_type = type_combo.get()
                new_price = price_entry.get().strip()
                
                if not all([new_room_num, new_type, new_price]):
                    messagebox.showerror("Error", "All fields required!")
                    return
                
                try:
                    price_float = float(new_price)
                except:
                    messagebox.showerror("Error", "Invalid price!")
                    return
                
                conn = get_connection()
                cur = conn.cursor()
                cur.execute("""UPDATE rooms SET 
                             room_number = ?, room_type = ?, price = ?
                             WHERE room_id = ?""",
                           (new_room_num, new_type, price_float, room_id))
                conn.commit()
                conn.close()
                
                messagebox.showinfo("Success", "Room updated!")
                edit_win.destroy()
                self.show_admin_rooms()
            
            tk.Button(edit_win, text="Save Changes", 
                     command=save_changes,
                     font=("Arial", 10, "bold"),
                     bg=self.success_color, fg="white",
                     width=15, cursor="hand2").pack(pady=20)
        
        tk.Button(action_frame, text="Update Status", 
                 command=update_status,
                 font=("Arial", 11),
                 bg=self.primary_color, fg="white",
                 width=15, cursor="hand2").pack(side=tk.LEFT, padx=10)
        
        tk.Button(action_frame, text="Edit Room", 
                 command=edit_room,
                 font=("Arial", 11),
                 bg=self.success_color, fg="white",
                 width=15, cursor="hand2").pack(side=tk.LEFT, padx=10)
    
    def show_add_room(self):
        """Thêm phòng mới"""
        add_win = tk.Toplevel(self.root)
        add_win.title("Add New Room")
        add_win.geometry("400x350")
        add_win.configure(bg=self.bg_color)
        add_win.grab_set()
        
        tk.Label(add_win, text="Add New Room", 
                font=("Arial", 18, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=20)
        
        fields = tk.Frame(add_win, bg=self.bg_color)
        fields.pack(pady=20, padx=30)
        
        tk.Label(fields, text="Room Number:", 
                font=("Arial", 10),
                bg=self.bg_color, fg=self.fg_color).grid(row=0, column=0, sticky="w", pady=8)
        room_num_entry = ttk.Entry(fields, width=20)
        room_num_entry.grid(row=0, column=1, pady=8, padx=10)
        
        tk.Label(fields, text="Room Type:", 
                font=("Arial", 10),
                bg=self.bg_color, fg=self.fg_color).grid(row=1, column=0, sticky="w", pady=8)
        type_combo = ttk.Combobox(fields, values=["Standard", "Deluxe", "Suite", "VIP"], width=18)
        type_combo.grid(row=1, column=1, pady=8, padx=10)
        type_combo.set("Standard")
        
        tk.Label(fields, text="Price:", 
                font=("Arial", 10),
                bg=self.bg_color, fg=self.fg_color).grid(row=2, column=0, sticky="w", pady=8)
        price_entry = ttk.Entry(fields, width=20)
        price_entry.grid(row=2, column=1, pady=8, padx=10)
        price_entry.insert(0, "500000")
        
        tk.Label(fields, text="Description:", 
                font=("Arial", 10),
                bg=self.bg_color, fg=self.fg_color).grid(row=3, column=0, sticky="w", pady=8)
        desc_entry = ttk.Entry(fields, width=20)
        desc_entry.grid(row=3, column=1, pady=8, padx=10)
        desc_entry.insert(0, "Standard room with basic amenities")
        
        def save_room():
            room_num = room_num_entry.get().strip()
            room_type = type_combo.get()
            price = price_entry.get().strip()
            desc = desc_entry.get().strip()
            
            if not all([room_num, room_type, price]):
                messagebox.showerror("Error", "Please fill required fields!")
                return
            
            try:
                price_float = float(price)
            except:
                messagebox.showerror("Error", "Invalid price!")
                return
            
            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("""INSERT INTO rooms 
                            (room_number, room_type, price, status, description)
                            VALUES (?, ?, ?, 'available', ?)""",
                          (room_num, room_type, price_float, desc))
                conn.commit()
                messagebox.showinfo("Success", "Room added!")
                add_win.destroy()
                self.show_admin_rooms()
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "Room number already exists!")
            finally:
                conn.close()
        
        tk.Button(add_win, text="Save Room", 
                 command=save_room,
                 font=("Arial", 11, "bold"),
                 bg=self.success_color, fg="white",
                 width=15, cursor="hand2").pack(pady=20)
    
    def show_admin_bookings(self):
        """Quản lý booking - Admin"""
        self.clear_admin_content()
        
        tk.Label(self.admin_content, text="Manage Bookings", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        table_frame = tk.Frame(self.admin_content, bg=self.bg_color)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        columns = ("ID", "Customer", "Room", "Check-in", "Check-out", "Status", "Amount")
        tree = ttk.Treeview(table_frame, columns=columns, height=15, show='tree headings')
        
        tree.column("#0", width=0, stretch=tk.NO)
        widths = [60, 120, 60, 90, 90, 80, 90]
        for col, width in zip(columns, widths):
            tree.column(col, anchor=tk.W, width=width)
            tree.heading(col, text=col, anchor=tk.W)
        
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load all bookings
        bookings = booking.get_all_bookings()
        for b in bookings:
            booking_id, customer, room, checkin, checkout, status, amount = b
            tree.insert("", "end", values=(
                booking_id, customer, room, checkin, checkout, status, f"{amount:,.0f} VND"
            ))
        
        # Action buttons
        action_frame = tk.Frame(self.admin_content, bg=self.bg_color)
        action_frame.pack(pady=20)
        
        def cancel_booking():
            selection = tree.selection()
            if not selection:
                messagebox.showerror("Error", "Select a booking!")
                return
            
            item = tree.item(selection[0])
            booking_id = item['values'][0]
            
            if messagebox.askyesno("Confirm", "Cancel this booking?"):
                success, message = booking.cancel_booking(booking_id)
                if success:
                    messagebox.showinfo("Success", message)
                    self.show_admin_bookings()
                else:
                    messagebox.showerror("Error", message)
        
        tk.Button(action_frame, text="Cancel Booking", 
                 command=cancel_booking,
                 font=("Arial", 11),
                 bg=self.warning_color, fg="white",
                 width=15, cursor="hand2").pack(side=tk.LEFT, padx=10)
    
    def show_admin_payments(self):
        """Quản lý thanh toán - Admin"""
        self.clear_admin_content()
        
        tk.Label(self.admin_content, text="Manage Payments", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        table_frame = tk.Frame(self.admin_content, bg=self.bg_color)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        columns = ("ID", "Booking ID", "Customer", "Amount", "Method", "Date")
        tree = ttk.Treeview(table_frame, columns=columns, height=15, show='tree headings')
        
        tree.column("#0", width=0, stretch=tk.NO)
        widths = [60, 80, 120, 100, 100, 120]
        for col, width in zip(columns, widths):
            tree.column(col, anchor=tk.W, width=width)
            tree.heading(col, text=col, anchor=tk.W)
        
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load all payments
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT p.payment_id, p.booking_id, u.full_name, 
                   p.amount, p.payment_method, p.payment_date
            FROM payments p
            JOIN bookings b ON p.booking_id = b.booking_id
            JOIN users u ON b.user_id = u.user_id
            ORDER BY p.payment_date DESC
        """)
        payments = cur.fetchall()
        conn.close()
        
        for p in payments:
            payment_id, booking_id, customer, amount, method, date = p
            tree.insert("", "end", values=(
                payment_id,
                booking_id,
                customer,
                f"{amount:,.0f} VND",
                method,
                date
            ))
    
    def show_admin_reviews(self):
        """Quản lý reviews - Admin"""
        self.clear_admin_content()
        
        tk.Label(self.admin_content, text="Manage Reviews", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        table_frame = tk.Frame(self.admin_content, bg=self.bg_color)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        columns = ("ID", "Booking ID", "Customer", "Rating", "Comment", "Date")
        tree = ttk.Treeview(table_frame, columns=columns, height=15, show='tree headings')
        
        tree.column("#0", width=0, stretch=tk.NO)
        widths = [60, 80, 100, 60, 150, 100]
        for col, width in zip(columns, widths):
            tree.column(col, anchor=tk.W, width=width)
            tree.heading(col, text=col, anchor=tk.W)
        
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load all reviews
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT r.review_id, r.booking_id, u.full_name, 
                   r.rating, r.comment, r.created_at
            FROM reviews r
            JOIN users u ON r.user_id = u.user_id
            ORDER BY r.created_at DESC
        """)
        reviews = cur.fetchall()
        conn.close()
        
        for r in reviews:
            review_id, booking_id, customer, rating, comment, date = r
            
            # Format comment
            display_comment = comment
            if len(comment) > 30:
                display_comment = comment[:30] + "..."
            
            # Format rating
            stars = "★" * rating + "☆" * (5 - rating)
            
            tree.insert("", "end", values=(
                review_id,
                booking_id,
                customer,
                stars,
                display_comment,
                date[:10]
            ))
        
        # Delete review button
        def delete_review():
            selection = tree.selection()
            if not selection:
                messagebox.showerror("Error", "Select a review!")
                return
            
            item = tree.item(selection[0])
            review_id = item['values'][0]
            
            if messagebox.askyesno("Confirm", "Delete this review?"):
                conn = get_connection()
                cur = conn.cursor()
                cur.execute("DELETE FROM reviews WHERE review_id = ?", (review_id,))
                conn.commit()
                conn.close()
                messagebox.showinfo("Success", "Review deleted!")
                self.show_admin_reviews()
        
        tk.Button(self.admin_content, text="Delete Review", 
                 command=delete_review,
                 font=("Arial", 11),
                 bg=self.warning_color, fg="white",
                 width=15, cursor="hand2").pack(pady=20)
    
    def show_admin_users(self):
        """Quản lý người dùng - Admin"""
        self.clear_admin_content()
        
        tk.Label(self.admin_content, text="Manage Users", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        table_frame = tk.Frame(self.admin_content, bg=self.bg_color)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        columns = ("ID", "Name", "Email", "Phone", "Role")
        tree = ttk.Treeview(table_frame, columns=columns, height=15, show='tree headings')
        
        tree.column("#0", width=0, stretch=tk.NO)
        widths = [50, 120, 180, 100, 80]
        for col, width in zip(columns, widths):
            tree.column(col, anchor=tk.W, width=width)
            tree.heading(col, text=col, anchor=tk.W)
        
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load all users
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT user_id, full_name, email, phone, role FROM users")
        users = cur.fetchall()
        conn.close()
        
        for u in users:
            user_id, name, email, phone, role = u
            tree.insert("", "end", values=(user_id, name, email, phone, role))
        
        # Action buttons
        action_frame = tk.Frame(self.admin_content, bg=self.bg_color)
        action_frame.pack(pady=20)
        
        def change_role():
            selection = tree.selection()
            if not selection:
                messagebox.showerror("Error", "Select a user!")
                return
            
            item = tree.item(selection[0])
            user_id = item['values'][0]
            current_role = item['values'][4]
            
            role_win = tk.Toplevel(self.root)
            role_win.title("Change Role")
            role_win.geometry("300x200")
            role_win.configure(bg=self.bg_color)
            role_win.grab_set()
            
            tk.Label(role_win, text="Select Role:", 
                    font=("Arial", 11),
                    bg=self.bg_color, fg=self.fg_color).pack(pady=20)
            
            role_var = tk.StringVar(value=current_role)
            role_combo = ttk.Combobox(role_win, textvariable=role_var,
                                     values=["customer", "admin"],
                                     state="readonly")
            role_combo.pack(pady=10)
            
            def save_role():
                conn = get_connection()
                cur = conn.cursor()
                cur.execute("UPDATE users SET role = ? WHERE user_id = ?", 
                           (role_var.get(), user_id))
                conn.commit()
                conn.close()
                messagebox.showinfo("Success", "Role updated!")
                role_win.destroy()
                self.show_admin_users()
            
            tk.Button(role_win, text="Save", 
                     command=save_role,
                     font=("Arial", 10, "bold"),
                     bg=self.success_color, fg="white",
                     width=10, cursor="hand2").pack(pady=20)
        
        tk.Button(action_frame, text="Change Role", 
                 command=change_role,
                 font=("Arial", 11),
                 bg=self.primary_color, fg="white",
                 width=15, cursor="hand2").pack(side=tk.LEFT, padx=10)
    
    def show_admin_analytics(self):
        """Phân tích - Admin"""
        self.clear_admin_content()
        
        tk.Label(self.admin_content, text="Analytics Dashboard", 
                font=("Arial", 24, "bold"),
                bg=self.bg_color, fg=self.fg_color).pack(pady=30)
        
        # Create sample charts
        fig, axes = plt.subplots(2, 2, figsize=(10, 8))
        
        # Get real data
        conn = get_connection()
        cur = conn.cursor()
        
        # Revenue by month (sample)
        months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
        revenue = [5000000, 7500000, 6000000, 9000000, 8000000, 12000000]
        
        # Room type distribution
        cur.execute("SELECT room_type, COUNT(*) FROM rooms GROUP BY room_type")
        room_types_data = cur.fetchall()
        room_types = []
        room_counts = []
        for r_type, count in room_types_data:
            room_types.append(r_type)
            room_counts.append(count)
        
        # Booking status
        cur.execute("SELECT status, COUNT(*) FROM bookings GROUP BY status")
        booking_status_data = cur.fetchall()
        
        conn.close()
        
        # Revenue chart
        axes[0, 0].plot(months, revenue, marker='o', color=self.primary_color, linewidth=2)
        axes[0, 0].set_title('Monthly Revenue')
        axes[0, 0].set_ylabel('Revenue (VND)')
        axes[0, 0].yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{x:,.0f}'))
        
        # Room distribution
        colors = [self.primary_color, self.success_color, self.warning_color, '#9B59B6']
        axes[0, 1].pie(room_counts[:4], labels=room_types[:4], colors=colors[:len(room_counts)], autopct='%1.1f%%')
        axes[0, 1].set_title('Room Type Distribution')
        
        # Booking status
        if booking_status_data:
            status_names = [s[0] for s in booking_status_data]
            status_counts = [s[1] for s in booking_status_data]
            status_colors = [self.success_color if s == 'paid' else self.warning_color if s == 'pending' else self.danger_color for s in status_names]
            axes[1, 0].bar(status_names, status_counts, color=status_colors)
            axes[1, 0].set_title('Booking Status')
            axes[1, 0].set_ylabel('Count')
        
        # Occupancy rate (sample)
        occupancy = [85, 90, 78, 92, 88, 95]
        axes[1, 1].bar(months, occupancy, color=self.warning_color)
        axes[1, 1].set_title('Monthly Occupancy Rate')
        axes[1, 1].set_ylabel('Occupancy (%)')
        axes[1, 1].set_ylim(0, 100)
        
        plt.tight_layout()
        
        # Embed chart
        canvas = FigureCanvasTkAgg(fig, self.admin_content)
        canvas.draw()
        canvas.get_tk_widget().pack(pady=20)
    
    def clear_admin_content(self):
        """Xóa nội dung admin"""
        for widget in self.admin_content.winfo_children():
            widget.destroy()

# ==================== RUN APPLICATION ====================
def run_app():
    """Chạy ứng dụng"""
    root = tk.Tk()
    app = HotelManagementUI(root)
    root.mainloop()

if __name__ == "__main__":
    run_app()