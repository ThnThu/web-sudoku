import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

import auth
import room
import booking
import admin
import review
from create_tables import create_tables
from seed_data import seed_all
from payment import create_payment


class HotelManagementUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Hotel Room Booking System")
        self.root.geometry("1000x650")
        self.root.resizable(False, False)
        self.current_user = None

        create_tables()
        seed_all()
        self.show_login_screen()

    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    # ================= LOGIN =================
    def show_login_screen(self):
        self.clear_window()
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(
            main_frame,
            text="🏨 HOTEL ROOM BOOKING",
            font=("Arial", 18, "bold")
        ).pack(pady=15)

        form_frame = ttk.LabelFrame(main_frame, text="Login", padding="15")
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)

        ttk.Label(form_frame, text="Email:").grid(row=0, column=0, sticky=tk.W, pady=8)
        email_entry = ttk.Entry(form_frame, width=35)
        email_entry.grid(row=0, column=1, pady=8)

        ttk.Label(form_frame, text="Password:").grid(row=1, column=0, sticky=tk.W, pady=8)
        password_entry = ttk.Entry(form_frame, width=35, show="*")
        password_entry.grid(row=1, column=1, pady=8)

        def login_action():
            user = auth.login(email_entry.get(), password_entry.get())
            if user:
                self.current_user = user
                if user["role"] == "admin":
                    self.show_admin_screen()
                else:
                    self.show_customer_screen()
            else:
                messagebox.showerror("Error", "Incorrect email or password")

        ttk.Button(form_frame, text="Login", command=login_action).grid(row=2, column=0)
        ttk.Button(form_frame, text="Register", command=self.show_register_screen).grid(row=2, column=1)

    # ================= REGISTER =================
    def show_register_screen(self):
        self.clear_window()
        frame = ttk.Frame(self.root, padding=20)
        frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(frame, text="Register", font=("Arial", 16, "bold")).pack(pady=10)

        form = ttk.Frame(frame)
        form.pack()

        entries = {}
        fields = [("Full Name", "name"), ("Email", "email"), ("Phone", "phone"), ("Password", "password")]

        for i, (label, key) in enumerate(fields):
            ttk.Label(form, text=label).grid(row=i, column=0, pady=5)
            e = ttk.Entry(form, width=30, show="*" if key == "password" else "")
            e.grid(row=i, column=1, pady=5)
            entries[key] = e

        def register_action():
            if auth.register(
                entries["name"].get(),
                entries["email"].get(),
                entries["password"].get(),
                entries["phone"].get()
            ):
                messagebox.showinfo("Success", "Register successful")
                self.show_login_screen()
            else:
                messagebox.showerror("Error", "Email already exists")

        ttk.Button(form, text="Register", command=register_action).grid(row=5, column=0)
        ttk.Button(form, text="Back", command=self.show_login_screen).grid(row=5, column=1)

    # ================= CUSTOMER =================
    def show_customer_screen(self):
        self.clear_window()

        header = ttk.Frame(self.root)
        header.pack(fill=tk.X, padx=10, pady=5)

        ttk.Label(header, text=f"Welcome, {self.current_user['full_name']}").pack(side=tk.LEFT)
        ttk.Button(header, text="Logout", command=self.show_login_screen).pack(side=tk.RIGHT)

        notebook = ttk.Notebook(self.root)
        notebook.pack(fill=tk.BOTH, expand=True)

        self.browse_rooms_tab(notebook)
        self.my_bookings_tab(notebook)

    # ================= BROWSE ROOMS =================
    def browse_rooms_tab(self, notebook):
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="Browse Rooms")

        columns = ("ID", "Name", "Type", "Price", "Status")
        tree = ttk.Treeview(frame, columns=columns, show="headings")

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=120)

        tree.pack(fill=tk.BOTH, expand=True)

        def load_rooms():
            tree.delete(*tree.get_children())
            for r in room.get_available_rooms():
                tree.insert("", tk.END, values=r)

        load_rooms()

    # ================= MY BOOKINGS =================
    def my_bookings_tab(self, notebook):
        frame = ttk.Frame(notebook)
        notebook.add(frame, text="My Bookings")

        columns = ("Booking ID", "Room", "Check-in", "Check-out", "Status")
        tree = ttk.Treeview(frame, columns=columns, show="headings")

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=130)

        tree.pack(fill=tk.BOTH, expand=True)

        def load_bookings():
            tree.delete(*tree.get_children())
            for b in booking.get_user_bookings(self.current_user["user_id"]):
                tree.insert("", tk.END, values=(b[0], b[2], b[3], b[4], b[5]))

        load_bookings()

        # ===== CANCEL =====
        def cancel_action():
            if not tree.selection():
                return
            booking_id = tree.item(tree.selection()[0])["values"][0]
            booking.cancel_booking(booking_id)
            load_bookings()

        # ===== PAY =====
        def pay_action():
            if not tree.selection():
                return

            booking_id = tree.item(tree.selection()[0])["values"][0]
            status = booking.get_booking_status(booking_id)

            if status == "paid":
                messagebox.showerror("Error", "This booking has already been paid!")
                return

            create_payment(booking_id, 500000, "cash")
            booking.mark_as_paid(booking_id)
            messagebox.showinfo("Success", "Payment successful!")
            load_bookings()

        # ===== REVIEW =====
        def review_action():
            if not tree.selection():
                return

            values = tree.item(tree.selection()[0])["values"]
            booking_id = values[0]

            ok, msg = review.can_review_booking(booking_id, self.current_user["user_id"])
            if not ok:
                messagebox.showerror("Error", msg)
                return

            review_win = tk.Toplevel(self.root)
            review_win.title("Đánh giá phòng")
            review_win.geometry("400x350")

            ttk.Label(review_win, text="Chọn số sao").pack(pady=5)
            rating_var = tk.IntVar(value=5)

            for i in range(1, 6):
                ttk.Radiobutton(
                    review_win,
                    text=f"{i} ⭐",
                    variable=rating_var,
                    value=i
                ).pack(anchor="w")

            ttk.Label(review_win, text="Nhận xét").pack(pady=5)
            comment_txt = tk.Text(review_win, height=5, width=40)
            comment_txt.pack()

            def submit_review():
                review.add_review(
                    booking_id,
                    self.current_user["user_id"],
                    None,
                    rating_var.get(),
                    comment_txt.get("1.0", tk.END).strip()
                )
                messagebox.showinfo("Success", "Đánh giá thành công!")
                review_win.destroy()

            ttk.Button(review_win, text="Gửi đánh giá", command=submit_review).pack(pady=10)

        btn_frame = ttk.Frame(frame)
        btn_frame.pack(pady=10)

        ttk.Button(btn_frame, text="Hủy Booking", command=cancel_action).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Thanh toán", command=pay_action).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Đánh giá", command=review_action).pack(side=tk.LEFT, padx=5)

    # ================= ADMIN =================
    def show_admin_screen(self):
        self.clear_window()
        ttk.Label(self.root, text="Admin Panel").pack()


def run_ui():
    root = tk.Tk()
    HotelManagementUI(root)
    root.mainloop()


if __name__ == "__main__":
    run_ui()
